package com.example.sqlitecompleto

//Classe como EstudanteModel com os atributos de um estudante
class EstudanteModel(
    var id: Int = 0,
    var nome: String = "",
    var email: String = ""
) {
}